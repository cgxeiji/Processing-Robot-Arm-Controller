import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 
import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class armInterfaceGUI extends PApplet {

// Need G4P library


PImage img_arm, img_xy, img_xz;

public void setup(){
  
  createGUI();
  customGUI();
  // Place your setup code here
  
  fileStatus = ERROR_NO_FILE_LOADED;
  setStatus(THIS_STAND_BY);
  
  x = _x = 190.0f;
  y = _y = 0.0f;
  z = _z = 40.0f;
  
  angles[0] = 90;
  angles[1] = 90;
  angles[2] = 90;
  angles[3] = 90;
  angles[4] = 90;
  
  names[0] = 'A';
  names[1] = 'B';
  names[2] = 'C';
  names[3] = 'D';
  names[4] = 'E';

  calibration[0] = 300;
  calibration[1] = 300;
  calibration[2] = 300;
  calibration[3] = 300;
  calibration[4] = 300;
  calibration[5] = 300;
  
  img_arm = loadImage("braccio_label.png");
  img_xy = loadImage("xy.png");
  img_xz = loadImage("xz.png");
  
  thread("checkConnection");
}

int centerXZ[] = {700+150, 80+150};
int centerXY[] = {700+150, 400+150};

public void draw(){  
  background(0);
  //fill(255, 0, 0, 100);
  //rect(700, 80, 300, 300);
  lGoalPosition.setText("[ Goal ]  X:" + nfs(x,3,1) + " Y:" + nfs(y,3,1) + " Z:" + nfs(z,3,1));
  lCurrentPosition.setText("[Current] X:" + nfs(_x,3,1) + " Y:" + nfs(_y,3,1) + " Z:" + nfs(_z,3,1));
  
  // Coordinates BG Images
  image(img_xz, 700, 80, 300, 300);
  image(img_xy, 700, 400, 300, 300);
  
  // Current Position Crosshair
  fill(255, 0, 0);
  ellipse(centerXY[0] + map(_x, -400, 400, -145, 145), centerXY[1] - map(_y, -400, 400, -145, 145), 10, 10);
  ellipse(centerXZ[0] + map(_x, -400, 400, -145, 145), centerXZ[1] - map(_z, -200, 400, -145, 145), 10, 10);
  
  // Braccio Image
  image(img_arm, 20, 200, 500, 500);
  if (!isConnected) {
    fill(0, 200);
    rect(0, 0, width, height);
  }
  
  // Move on the X Y Z plane with the keyboard
  if (kb.isPressed('w')) {
    y += 1.0f;
    slider2dXY.setValueY(y);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }
  if (kb.isPressed('s')) {
    y -= 1.0f;
    slider2dXY.setValueY(y);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }
  if (kb.isPressed('a')) {
    x -= 1.0f;
    slider2dXY.setValueX(x);
    //slider2dXZ.setValueX(x);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }
  if (kb.isPressed('d')) {
    x += 1.0f;
    slider2dXY.setValueX(x);
    //slider2dXZ.setValueX(x);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }
  if (kb.isPressed('r')) {
    z += 1.0f;
    slider2dXZ.setValueY(z);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }
  if (kb.isPressed('f')) {
    z -= 1.0f;
    slider2dXZ.setValueY(z);
    //send("G01 X" + x + " Y" + y + " Z" + z + " F100");
  }

  // Open and close the grip
  if (kb.pushedOnce('q')) {
    bGrip_click1(bGrip, GEvent.CLICKED);
  }

  // Enable / Disable calibration mode
  if (kb.pushedOnce('y')) {
    calibrationMode = !calibrationMode;
    if (calibrationMode) {
      send("M103");
      println("Calibration Mode Enabled");
    } else {
      send("M104");
      println("Calibration Mode Disabled");
    }
  }

  // Move each motor individually
  if (kb.pushedOnce('0')) {
    joint = 0;
  }
  if (kb.pushedOnce('1')) {
    joint = 1;
  }
  if (kb.pushedOnce('2')) {
    joint = 2;
  }
  if (kb.pushedOnce('3')) {
    joint = 3;
  }
  if (kb.pushedOnce('4')) {
    joint = 4;
  }
  if (kb.pushedOnce('5')) {
    joint = 5;
  }
  if (kb.isPressed('m')) {
    if (calibrationMode) {
      calibration[joint] -= 1.0f;
      send("G54 " + names[joint] + "" + calibration[joint]);
    } else {
      angles[joint] -= 1.0f;
      send("G53 " + names[joint] + "" + angles[joint]);
    }
  }
  if (kb.isPressed('n')) {
    if (calibrationMode) {
      calibration[joint] += 1.0f;
      send("G54 " + names[joint] + "" + calibration[joint]);
    } else {
      angles[joint] += 1.0f;
      send("G53 " + names[joint] + "" + angles[joint]);
    }
  }

  /* TODO: decide if stays or not
  if (kb.pushedOnce('u')) {
    angles[0] = 90;
    angles[1] = 90;
    angles[2] = 90;
    angles[3] = 90;
    angles[4] = 90;
    angles[5] = 10;
    send("M105");
    calibration[0] = 300;
    calibration[1] = 300;
    calibration[2] = 300;
    calibration[3] = 300;
    calibration[4] = 300;
    calibration[5] = 300;
  }
  if (kb.pushedOnce('i')) {
    angles[0] = 180;
    angles[1] = 45;
    angles[2] = 180;
    angles[3] = 0;
    angles[4] = 0;
    angles[5] = 73;
    send("M107");
    calibration[0] = 300;
    calibration[1] = 300;
    calibration[2] = 300;
    calibration[3] = 300;
    calibration[4] = 300;
    calibration[5] = 300;
  }
  if (kb.pushedOnce('j')) {
    send("M106 A" + calibration[0] + " B" + calibration[1] + " C" + calibration[2] + " D" + calibration[3] + " E" + calibration[4] + " F" + calibration[5]);
    angles[0] = 90;
    angles[1] = 90;
    angles[2] = 90;
    angles[3] = 90;
    angles[4] = 90;
    angles[5] = 10;
  }
  if (kb.pushedOnce('k')) {
    send("M108 A" + calibration[0] + " B" + calibration[1] + " C" + calibration[2] + " D" + calibration[3] + " E" + calibration[4] + " F" + calibration[5]);
    angles[0] = 180;
    angles[1] = 45;
    angles[2] = 180;
    angles[3] = 0;
    angles[4] = 0;
    angles[5] = 73;
  }
  */

}

// Use this method to add additional statements
// to customise the GUI controls
public void customGUI(){
  dlPorts.setItems(Serial.list(), 0);
  
  x = 190;
  y = 0;
  z = 40;
  
  lCurrentPosition.setFont(FontManager.getFont("Consolas", 1, 30));
  lGoalPosition.setFont(FontManager.getFont("Consolas", 0, 30));
  lAttack.setText("Attack Angle: " + nfs(-kAttack.getValueF(), 2, 1));
  
  slider2dXZ.setValueX(x);
  slider2dXZ.setValueY(z);
  slider2dXY.setValueX(x);
  slider2dXY.setValueY(y);
  
  kBase.setValue(90);
  kShoulder.setValue(90);
  kElbow.setValue(90);
  kWrist.setValue(90);
  kHand.setValue(90);
  kAttack.setValue(-45);
  attackAngle = -45;
  
  kBase.setEnabled(false);
  kShoulder.setEnabled(false);
  kElbow.setEnabled(false);
  kWrist.setEnabled(false);
  
  tConsole.setTextEditEnabled(false);
  tConsole.setVisible(false); //
  
  deactivateControls();
  
  bSend.setAlpha(50);
  
  b90Send.setAlpha(50);
  b0Send.setAlpha(50);
}
public boolean arm_isCmd(String s, String cmd) {
  int index = s.indexOf(cmd);

  return index != -1;
}

public float arm_getValue(String s, String cmd) {
  int sIndex = s.indexOf(cmd);
  int eIndex = s.indexOf(' ', sIndex);

  String value;

  if (eIndex == -1) {
    value = s.substring(sIndex+1);
  } else {
    value = s.substring(sIndex+1, eIndex);
  }

  return PApplet.parseFloat(value);
}
class Keyboard {
  IntDict keymap = new IntDict();
  IntDict pKeymap = new IntDict();
  
  String input = "";
  boolean record = false;
  
  Keyboard() {
    for(int i = 'a'; i < 'z'+1; i++) {
      keymap.set(str(PApplet.parseChar(i)), 0);
      pKeymap.set(str(PApplet.parseChar(i)), 0);
    }
    for(int i = '0'; i < '9'+1; i++) {
      keymap.set(str(PApplet.parseChar(i)), 0);
      pKeymap.set(str(PApplet.parseChar(i)), 0);
    }
    keymap.set(" ", 0);
    pKeymap.set(" ", 0);
  }
  
  public boolean pushedOnce(char k) {
    boolean state = pKeymap.get(str(k)) == 0 && keymap.get(str(k)) == 1;
    update(k);
    return state;
  }
  
  public boolean isReleased(char k) {
    boolean state = pKeymap.get(str(k)) == 1 && keymap.get(str(k)) == 0;
    update(k);
    return state;
  }
  
  public boolean isPressed(char k) {
    return keymap.get(str(k)) == 1;
  }
  
  public void update(char k, boolean b) {
    pKeymap.set(str(k), keymap.get(str(k)));
    keymap.set(str(k), (b == true ? 1 : 0));
  }
  
  public void update(char k) {
    pKeymap.set(str(k), keymap.get(str(k)));
  }
}

Keyboard kb = new Keyboard();

public void keyPressed() {
  if (!kb.record) {
    if (key >= 'a' && key <= 'z' || key >= '0' && key <= '9' || key == ' ') {
      kb.update(key, true);
    }
  } else {
    if (keyCode == BACKSPACE) {
      if (kb.input.length() > 0) {
        kb.input = kb.input.substring(0, kb.input.length()-1);
      }
    } else if (keyCode == DELETE) {
      kb.input = "";
    } else if (keyCode == ENTER) {
      kb.record = false;
    } else if (keyCode != SHIFT && keyCode != CONTROL && keyCode != ALT) {
      kb.input = kb.input + key;
    }
  }
}

public void keyReleased() {
  if (!kb.record) {
    if (key >= 'a' && key <= 'z' || key >= '0' && key <= '9' || key == ' ') {
      kb.update(key, false);
    }
  }
}
boolean isDone = true, sendingGcode = false, isReceiving = false;

public void sender_start() {
  if (isConnected) {
    sendingGcode = true;
    String[] codes = loadStrings(gcodeFile);
    
    for (String line : codes) {
      if (arm_isCmd(line, "G01") || arm_isCmd(line, "G00")) {
        x = arm_getValue(line, "X");
        y = arm_getValue(line, "Y");
        z = arm_getValue(line, "Z");
      }
      if (arm_isCmd(line, "G28")) {
        x = 195;
        y = 0;
        z = 50;
      }
      
      slider2dXY.setValueX(x);
      slider2dXY.setValueY(y);
      slider2dXZ.setValueY(z);
      
      send(line);
      
      while(!isDone) {
        if (!sendingGcode) return;
        delay(100);
      }
    }
    sendingGcode = false;
  }
}

public void home() {
  x = 195;
  y = 0;
  z = 50;
  slider2dXY.setValueX(x);
  slider2dXY.setValueY(y);
  slider2dXZ.setValueY(z);
}

public void send(String line) {
  if (isConnected) {
    if (isDone) {
      lockdown();
      isDone = false;
      arm.write(line + '\n');
      debugger = line + '\n';
      println(debugger);
      setStatus(ARM_SENT);
      thread("timeoutTimer");
    }
  }
}

public void timeoutTimer() {
  int counter = 0;
  while(!isDone) {
    if (isReceiving) {
      counter = 0;
      isReceiving = false;
    }
    delay(100);
    counter += 100;
    if (counter >= 5000) {
      setStatus(ERROR_TIMEOUT);
      isDone = true;
      lockup();
    }
  }
}


Serial arm;

public boolean serialEnable(String port) {
  arm = new Serial(this, port, 115200);
  arm.bufferUntil(10);
  
  return arm != null;
}

public boolean serialDisable() {
  if (arm == null) return true;
  
  arm.clear();
  arm.stop();
  arm = null;
  return true;
}

public void checkConnection() {
  while(true) {
    if (isConnected) {
      if (arm == null) {
        serialDisconnect();
      }
    }
  }
}

public void serialEvent(Serial p) {
  String s =  p.readString();
  isReceiving = true;
  
  if (arm_isCmd(s, "$0")) {
    angles[0] = arm_getValue(s, "A");
    angles[1] = arm_getValue(s, "B");
    angles[2] = arm_getValue(s, "C");
    angles[3] = arm_getValue(s, "D");
    angles[4] = arm_getValue(s, "E");
    
    kBase.setValue(angles[0]);
    kShoulder.setValue(angles[1]);
    kElbow.setValue(angles[2]);
    kWrist.setValue(angles[3]);
    
    return;
  }
  if (arm_isCmd(s, "$1")) {
    _x = arm_getValue(s, "X");
    _y = arm_getValue(s, "Y");
    _z = arm_getValue(s, "Z");

    slider2dXY.setLocalColorScheme(GCScheme.GREEN_SCHEME);
    slider2dXZ.setLocalColorScheme(GCScheme.GREEN_SCHEME);
    return;
  }
  
  if (s.indexOf("ok") == -1) {
    debugger = s;
    if (s.indexOf("Invalid") != -1) {
      slider2dXY.setLocalColorScheme(GCScheme.RED_SCHEME);
      slider2dXZ.setLocalColorScheme(GCScheme.RED_SCHEME);
    }
  } else {
    setStatus(ARM_STAND_BY);
    debugger += "   ...done!\n";
    println(debugger);
    isDone = true;
    lockup();
  }
}

boolean isConnected = false;

public void serialConnect() {
  if (!serialEnable(dlPorts.getSelectedText())) return;
  
  bConnect.setText("Disconnect");
  bConnect.setLocalColorScheme(GCScheme.RED_SCHEME);
  
  activateControls();
  
  setStatus(ARM_STAND_BY);
  
  isConnected = true;
}

public void serialDisconnect() {
  serialDisable();
  
  bConnect.setText("Connect");
  bConnect.setLocalColorScheme(GCScheme.GREEN_SCHEME);
  
  deactivateControls();
  
  isConnected = false;
}
/* =========================================================
 * ====                   WARNING                        ===
 * =========================================================
 * The code in this tab has been generated from the GUI form
 * designer and care should be taken when editing this file.
 * Only add/edit code inside the event handlers i.e. only
 * use lines between the matching comment tags. e.g.

 void myBtnEvents(GButton button) { //_CODE_:button1:12356:
     // It is safe to enter your event code here  
 } //_CODE_:button1:12356:
 
 * Do not rename this tab!
 * =========================================================
 */

public void slider2dXY_change1(GSlider2D source, GEvent event) { //_CODE_:slider2dXY:587720:
  x = source.getValueXF();
  y = source.getValueYF();
  
  slider2dXZ.setValueX(x);
  
  if (!sendingGcode)
    send("G01 X" + x + " Y" + y + " Z" + z + " W" + attackAngle + " F100");
} //_CODE_:slider2dXY:587720:

public void slider2dXZ_change1(GSlider2D source, GEvent event) { //_CODE_:slider2dXZ:951220:
  x = source.getValueXF();
  z = source.getValueYF();
  
  slider2dXY.setValueX(x);
  
  if (!sendingGcode)
    send("G01 X" + x + " Y" + y + " Z" + z + " W" + attackAngle + " F100");
} //_CODE_:slider2dXZ:951220:

public void dlPorts_click1(GDropList source, GEvent event) { //_CODE_:dlPorts:522580:
  println("dlPorts - GDropList >> GEvent." + event + " @ " + millis());
} //_CODE_:dlPorts:522580:

public void bConnect_click1(GButton source, GEvent event) { //_CODE_:bConnect:427343:
if (!isConnected) {
    serialConnect();
  } else {
    serialDisconnect();
  }
} //_CODE_:bConnect:427343:

public void kAttack_turn1(GKnob source, GEvent event) { //_CODE_:kAttack:927495:
  attackAngle = kAttack.getValueF();
  lAttack.setText("Attack Angle: " + nfs(attackAngle, 2, 1));
  send("G01 X" + x + " Y" + y + " Z" + z + " W" + attackAngle + " F100");
} //_CODE_:kAttack:927495:

public void cbAttack_clicked1(GCheckbox source, GEvent event) { //_CODE_:cbAttack:710322:
  if (cbAttack.isSelected()) {
    cbAttack.setLocalColorScheme(GCScheme.GREEN_SCHEME);
    kAttack.setLocalColorScheme(GCScheme.RED_SCHEME);
    lAttack.setLocalColorScheme(GCScheme.RED_SCHEME);
    kAttack.setEnabled(false);
    lAttack.setEnabled(false);
    attackAngle = 999.9f;
    send("G01 X" + x + " Y" + y + " Z" + z + " W" + attackAngle + " F100");
  } else {
    cbAttack.setLocalColorScheme(GCScheme.RED_SCHEME);
    kAttack.setLocalColorScheme(GCScheme.GREEN_SCHEME);
    lAttack.setLocalColorScheme(GCScheme.GREEN_SCHEME);
    kAttack.setEnabled(true);
    lAttack.setEnabled(true);
    attackAngle = kAttack.getValueF();
    send("G01 X" + x + " Y" + y + " Z" + z + " W" + attackAngle + " F100");
  }
} //_CODE_:cbAttack:710322:

public void kBase_turn1(GKnob source, GEvent event) { //_CODE_:kBase:713256:
  lBase.setText("Base " + nf(kBase.getValueF(), 3, 2));
} //_CODE_:kBase:713256:

public void b90_click1(GButton source, GEvent event) { //_CODE_:b90:200019:
  angles[0] = 90;
  angles[1] = 90;
  angles[2] = 90;
  angles[3] = 90;
  angles[4] = 90;
  send("M105");
  calibrationMode = true;
  b0Send.setAlpha(50);
  b90Send.setAlpha(255);
} //_CODE_:b90:200019:

public void kWrist_turn1(GKnob source, GEvent event) { //_CODE_:kWrist:376624:
  lWrist.setText("Wrist " + nf(kWrist.getValueF(), 3, 2));
} //_CODE_:kWrist:376624:

public void kElbow_turn1(GKnob source, GEvent event) { //_CODE_:kElbow:971784:
  lElbow.setText("Elbow " + nf(kElbow.getValueF(), 3, 2));
} //_CODE_:kElbow:971784:

public void kShoulder_turn1(GKnob source, GEvent event) { //_CODE_:kShoulder:598142:
  lShoulder.setText("Shoulder " + nf(kShoulder.getValueF(), 3, 2));
} //_CODE_:kShoulder:598142:

public void kHand_turn1(GKnob source, GEvent event) { //_CODE_:kHand:608494:
  lHand.setText("Hand " + nf(kHand.getValueF(), 3, 2));
  angles[4] = kHand.getValueF();
  send("G53 E" + angles[4]);
} //_CODE_:kHand:608494:

public void bGrip_click1(GButton source, GEvent event) { //_CODE_:bGrip:769454:
  if (bGrip.getText() == "OPEN") {
    send("M101");
    bGrip.setText("CLOSE");
    bGrip.setLocalColorScheme(GCScheme.RED_SCHEME);
  } else {
    send("M100");
    bGrip.setText("OPEN");
    bGrip.setLocalColorScheme(GCScheme.GREEN_SCHEME);
  }
} //_CODE_:bGrip:769454:

public void tConsole_change1(GTextArea source, GEvent event) { //_CODE_:tConsole:639074:
  String[] log = tConsole.getTextAsArray();
  tConsole.moveCaretTo(log.length - 1, 0);
} //_CODE_:tConsole:639074:

public void bLoad_click1(GButton source, GEvent event) { //_CODE_:bLoad:604636:
  setStatus(THIS_FILE_REQUESTED);
  selectInput("Select gcode file:", "parseFile");
} //_CODE_:bLoad:604636:

public void bSend_click1(GButton source, GEvent event) { //_CODE_:bSend:720434:
  setStatus(THIS_SENDER_START_REQUESTED);
  if (fileStatus == THIS_FILE_LOADED) {
    setStatus(ARM_STAND_BY);
    thread("sender_start");
  } else {
    setStatus(ERROR_NO_FILE_LOADED);
    setStatus(ARM_STAND_BY);
  }
} //_CODE_:bSend:720434:

public void b0_click1(GButton source, GEvent event) { //_CODE_:b0:427289:
  angles[0] = 180;
  angles[1] = 45;
  angles[2] = 180;
  angles[3] = 0;
  angles[4] = 0;
  send("M107");
  calibrationMode = true;
  b90Send.setAlpha(50);
  b0Send.setAlpha(255);
} //_CODE_:b0:427289:

public void b0Send_click1(GButton source, GEvent event) { //_CODE_:b0Send:359807:
  send("M108 A" + angles[0] + " B" + angles[1] + " C" + angles[2] + " D" + angles[3] + " E" + angles[4]);
  angles[0] = 180;
  angles[1] = 45;
  angles[2] = 180;
  angles[3] = 0;
  angles[4] = 0;
  calibrationMode = false;
  b0Send.setAlpha(50);
} //_CODE_:b0Send:359807:

public void b90Send_click1(GButton source, GEvent event) { //_CODE_:b90Send:430743:
  send("M106 A" + angles[0] + " B" + angles[1] + " C" + angles[2] + " D" + angles[3] + " E" + angles[4]);
  angles[0] = 90;
  angles[1] = 90;
  angles[2] = 90;
  angles[3] = 90;
  angles[4] = 90;
  calibrationMode = false;
  b90Send.setAlpha(50);
} //_CODE_:b90Send:430743:

public void bHome_click1(GButton source, GEvent event) { //_CODE_:bHome:330187:
  send("G28");
  home();
  calibrationMode = false;
  b0Send.setAlpha(50);
  b90Send.setAlpha(50);
} //_CODE_:bHome:330187:



// Create all the GUI controls. 
// autogenerated do not edit
public void createGUI(){
  G4P.messagesEnabled(false);
  G4P.setGlobalColorScheme(GCScheme.GREEN_SCHEME);
  G4P.setCursor(ARROW);
  surface.setTitle("Arm Controller");
  slider2dXY = new GSlider2D(this, 700, 400, 300, 300);
  slider2dXY.setLimitsX(190.0f, -400.0f, 400.0f);
  slider2dXY.setLimitsY(400.0f, 400.0f, -400.0f);
  slider2dXY.setNumberFormat(G4P.DECIMAL, 2);
  slider2dXY.setOpaque(false);
  slider2dXY.addEventHandler(this, "slider2dXY_change1");
  slider2dXZ = new GSlider2D(this, 700, 80, 300, 300);
  slider2dXZ.setLimitsX(1.0f, -400.0f, 400.0f);
  slider2dXZ.setLimitsY(40.0f, 400.0f, -200.0f);
  slider2dXZ.setNumberFormat(G4P.DECIMAL, 2);
  slider2dXZ.setOpaque(false);
  slider2dXZ.addEventHandler(this, "slider2dXZ_change1");
  lCurrentPosition = new GLabel(this, 10, 10, 670, 40);
  lCurrentPosition.setTextAlign(GAlign.LEFT, GAlign.TOP);
  lCurrentPosition.setText("[Current]");
  lCurrentPosition.setTextBold();
  lCurrentPosition.setOpaque(false);
  dlPorts = new GDropList(this, 700, 10, 90, 80, 3);
  dlPorts.setItems(loadStrings("list_522580"), 0);
  dlPorts.addEventHandler(this, "dlPorts_click1");
  bConnect = new GButton(this, 820, 10, 80, 20);
  bConnect.setText("Connect");
  bConnect.setTextBold();
  bConnect.addEventHandler(this, "bConnect_click1");
  lGoalPosition = new GLabel(this, 10, 50, 670, 40);
  lGoalPosition.setTextAlign(GAlign.LEFT, GAlign.TOP);
  lGoalPosition.setText("[Goal]");
  lGoalPosition.setLocalColorScheme(GCScheme.ORANGE_SCHEME);
  lGoalPosition.setOpaque(false);
  kAttack = new GKnob(this, 10, 120, 100, 100, 0.8f);
  kAttack.setTurnRange(270, 90);
  kAttack.setTurnMode(GKnob.CTRL_ANGULAR);
  kAttack.setShowArcOnly(false);
  kAttack.setOverArcOnly(false);
  kAttack.setIncludeOverBezel(false);
  kAttack.setShowTrack(false);
  kAttack.setLimits(-45.0f, 90.0f, -90.0f);
  kAttack.setNbrTicks(38);
  kAttack.setShowTicks(true);
  kAttack.setOpaque(false);
  kAttack.addEventHandler(this, "kAttack_turn1");
  lAttack = new GLabel(this, 10, 220, 156, 20);
  lAttack.setText("Attack Angle:");
  lAttack.setOpaque(false);
  cbAttack = new GCheckbox(this, 10, 240, 155, 20);
  cbAttack.setIconAlign(GAlign.LEFT, GAlign.MIDDLE);
  cbAttack.setText("Free Attack Angle?");
  cbAttack.setTextBold();
  cbAttack.setLocalColorScheme(GCScheme.RED_SCHEME);
  cbAttack.setOpaque(false);
  cbAttack.addEventHandler(this, "cbAttack_clicked1");
  kBase = new GKnob(this, 415, 610, 60, 60, 0.8f);
  kBase.setTurnRange(180, 0);
  kBase.setTurnMode(GKnob.CTRL_HORIZONTAL);
  kBase.setSensitivity(1);
  kBase.setShowArcOnly(true);
  kBase.setOverArcOnly(false);
  kBase.setIncludeOverBezel(false);
  kBase.setShowTrack(false);
  kBase.setLimits(90.0f, 180.0f, 0.0f);
  kBase.setNbrTicks(20);
  kBase.setShowTicks(true);
  kBase.setLocalColorScheme(GCScheme.RED_SCHEME);
  kBase.setOpaque(false);
  kBase.addEventHandler(this, "kBase_turn1");
  lBase = new GLabel(this, 415, 640, 60, 40);
  lBase.setTextAlign(GAlign.CENTER, GAlign.TOP);
  lBase.setText("Base");
  lBase.setLocalColorScheme(GCScheme.RED_SCHEME);
  lBase.setOpaque(false);
  b90 = new GButton(this, 580, 660, 80, 30);
  b90.setText("Calibrate [_]");
  b90.setTextBold();
  b90.setLocalColorScheme(GCScheme.GOLD_SCHEME);
  b90.addEventHandler(this, "b90_click1");
  kWrist = new GKnob(this, 414, 233, 60, 60, 0.8f);
  kWrist.setTurnRange(180, 0);
  kWrist.setTurnMode(GKnob.CTRL_HORIZONTAL);
  kWrist.setSensitivity(1);
  kWrist.setShowArcOnly(true);
  kWrist.setOverArcOnly(false);
  kWrist.setIncludeOverBezel(false);
  kWrist.setShowTrack(false);
  kWrist.setLimits(90.0f, 180.0f, 0.0f);
  kWrist.setNbrTicks(20);
  kWrist.setShowTicks(true);
  kWrist.setLocalColorScheme(GCScheme.RED_SCHEME);
  kWrist.setOpaque(false);
  kWrist.addEventHandler(this, "kWrist_turn1");
  kElbow = new GKnob(this, 415, 343, 60, 60, 0.8f);
  kElbow.setTurnRange(180, 0);
  kElbow.setTurnMode(GKnob.CTRL_HORIZONTAL);
  kElbow.setSensitivity(1);
  kElbow.setShowArcOnly(true);
  kElbow.setOverArcOnly(false);
  kElbow.setIncludeOverBezel(false);
  kElbow.setShowTrack(false);
  kElbow.setLimits(90.0f, 180.0f, 0.0f);
  kElbow.setNbrTicks(20);
  kElbow.setShowTicks(true);
  kElbow.setLocalColorScheme(GCScheme.RED_SCHEME);
  kElbow.setOpaque(false);
  kElbow.addEventHandler(this, "kElbow_turn1");
  kShoulder = new GKnob(this, 415, 505, 60, 60, 0.8f);
  kShoulder.setTurnRange(195, 345);
  kShoulder.setTurnMode(GKnob.CTRL_HORIZONTAL);
  kShoulder.setSensitivity(1);
  kShoulder.setShowArcOnly(true);
  kShoulder.setOverArcOnly(false);
  kShoulder.setIncludeOverBezel(false);
  kShoulder.setShowTrack(false);
  kShoulder.setLimits(90.0f, 165.0f, 15.0f);
  kShoulder.setNbrTicks(20);
  kShoulder.setShowTicks(true);
  kShoulder.setLocalColorScheme(GCScheme.RED_SCHEME);
  kShoulder.setOpaque(false);
  kShoulder.addEventHandler(this, "kShoulder_turn1");
  kHand = new GKnob(this, 62, 368, 60, 60, 0.8f);
  kHand.setTurnRange(180, 0);
  kHand.setTurnMode(GKnob.CTRL_HORIZONTAL);
  kHand.setSensitivity(1);
  kHand.setShowArcOnly(true);
  kHand.setOverArcOnly(false);
  kHand.setIncludeOverBezel(false);
  kHand.setShowTrack(false);
  kHand.setLimits(90.0f, 180.0f, 0.0f);
  kHand.setNbrTicks(20);
  kHand.setShowTicks(true);
  kHand.setOpaque(false);
  kHand.addEventHandler(this, "kHand_turn1");
  bGrip = new GButton(this, 68, 588, 50, 50);
  bGrip.setText("OPEN");
  bGrip.addEventHandler(this, "bGrip_click1");
  lShoulder = new GLabel(this, 415, 535, 60, 40);
  lShoulder.setTextAlign(GAlign.CENTER, GAlign.TOP);
  lShoulder.setText("Shoulder");
  lShoulder.setLocalColorScheme(GCScheme.RED_SCHEME);
  lShoulder.setOpaque(false);
  lElbow = new GLabel(this, 415, 373, 60, 40);
  lElbow.setTextAlign(GAlign.CENTER, GAlign.TOP);
  lElbow.setText("Elbow");
  lElbow.setLocalColorScheme(GCScheme.RED_SCHEME);
  lElbow.setOpaque(false);
  lWrist = new GLabel(this, 415, 263, 60, 40);
  lWrist.setTextAlign(GAlign.CENTER, GAlign.TOP);
  lWrist.setText("Wrist");
  lWrist.setLocalColorScheme(GCScheme.RED_SCHEME);
  lWrist.setOpaque(false);
  lHand = new GLabel(this, 62, 398, 60, 40);
  lHand.setTextAlign(GAlign.CENTER, GAlign.TOP);
  lHand.setText("Hand");
  lHand.setOpaque(false);
  tConsole = new GTextArea(this, 138, 94, 542, 108, G4P.SCROLLBARS_VERTICAL_ONLY | G4P.SCROLLBARS_AUTOHIDE);
  tConsole.setLocalColorScheme(GCScheme.ORANGE_SCHEME);
  tConsole.setOpaque(false);
  tConsole.addEventHandler(this, "tConsole_change1");
  label1 = new GLabel(this, 689, 380, 80, 20);
  label1.setText("XY");
  label1.setTextBold();
  label1.setOpaque(false);
  label2 = new GLabel(this, 689, 60, 80, 20);
  label2.setText("XZ");
  label2.setTextBold();
  label2.setOpaque(false);
  bLoad = new GButton(this, 920, 40, 80, 20);
  bLoad.setText("Load file");
  bLoad.setTextBold();
  bLoad.addEventHandler(this, "bLoad_click1");
  lFile = new GLabel(this, 700, 40, 214, 20);
  lFile.setText("File:");
  lFile.setOpaque(true);
  bSend = new GButton(this, 920, 10, 80, 20);
  bSend.setText("Send Gcode");
  bSend.setTextBold();
  bSend.setLocalColorScheme(GCScheme.ORANGE_SCHEME);
  bSend.addEventHandler(this, "bSend_click1");
  b0 = new GButton(this, 580, 620, 80, 30);
  b0.setText("Calibrate /\\");
  b0.setTextBold();
  b0.setLocalColorScheme(GCScheme.BLUE_SCHEME);
  b0.addEventHandler(this, "b0_click1");
  b0Send = new GButton(this, 665, 620, 30, 30);
  b0Send.setText("/\\");
  b0Send.setTextBold();
  b0Send.setLocalColorScheme(GCScheme.BLUE_SCHEME);
  b0Send.addEventHandler(this, "b0Send_click1");
  b90Send = new GButton(this, 665, 660, 30, 30);
  b90Send.setText("[_]");
  b90Send.setTextBold();
  b90Send.setLocalColorScheme(GCScheme.GOLD_SCHEME);
  b90Send.addEventHandler(this, "b90Send_click1");
  bHome = new GButton(this, 580, 560, 115, 30);
  bHome.setText("HOME");
  bHome.setTextBold();
  bHome.addEventHandler(this, "bHome_click1");
}

// Variable declarations 
// autogenerated do not edit
GSlider2D slider2dXY; 
GSlider2D slider2dXZ; 
GLabel lCurrentPosition; 
GDropList dlPorts; 
GButton bConnect; 
GLabel lGoalPosition; 
GKnob kAttack; 
GLabel lAttack; 
GCheckbox cbAttack; 
GKnob kBase; 
GLabel lBase; 
GButton b90; 
GKnob kWrist; 
GKnob kElbow; 
GKnob kShoulder; 
GKnob kHand; 
GButton bGrip; 
GLabel lShoulder; 
GLabel lElbow; 
GLabel lWrist; 
GLabel lHand; 
GTextArea tConsole; 
GLabel label1; 
GLabel label2; 
GButton bLoad; 
GLabel lFile; 
GButton bSend; 
GButton b0; 
GButton b0Send; 
GButton b90Send; 
GButton bHome; 
File gcodeFile;
String status;
String fileStatus;

String ERROR_NOT_GCODE_FILE = "File is not gcode";
String THIS_FILE_LOADED = "File successfully loaded";
String THIS_FILE_REQUESTED = "File has been requested";
String ERROR_NO_FILE_LOADED = "No file has been loaded";

String ERROR_TIMEOUT = "Timeout Error";
String ARM_ACK = "Received acknowledge from arm";
String ARM_STAND_BY = "Arm standing by";
String ARM_SENT = "Command sent to arm";

String THIS_SENDER_START_REQUESTED = "Start of gcode requested";

String THIS_STAND_BY = "Controller standing by";

String debugger = "";

float angles[] = new float[5];
char names[] = new char[5];
float calibration[] = new float[6];

float x, y, z, _x, _y, _z;
boolean open = true;
boolean calibrationMode = false;

float attackAngle;

int joint = 0;

public void parseFile(File selected) {
  if (selected == null) {
    setStatus(ERROR_NOT_GCODE_FILE);
    setStatus(ARM_STAND_BY);
  } else {
    if (isGcode(selected)) {
      setStatus(THIS_FILE_LOADED);
      fileStatus = THIS_FILE_LOADED;
      gcodeFile = selected;
      lFile.setText("File: " + gcodeFile.getName());
      bSend.setAlpha(255);
      setStatus(ARM_STAND_BY);
    } else {
      setStatus(ERROR_NOT_GCODE_FILE);
      setStatus(ARM_STAND_BY);
    }
  }
}

public void setStatus(String code) {
  status = code;
  println(status);
}

public boolean isGcode(File file) {
  if (file.getAbsolutePath().toLowerCase().endsWith(".gcode")) {
    return true;
  }
  return false;
}

public void setControls(int alpha) {
  kAttack.setAlpha(alpha);
  lAttack.setAlpha(alpha);
  cbAttack.setAlpha(alpha);
  
  kBase.setAlpha(alpha);
  kShoulder.setAlpha(alpha);
  kElbow.setAlpha(alpha);
  kWrist.setAlpha(alpha);
  kHand.setAlpha(alpha);
  
  lBase.setAlpha(alpha);
  lShoulder.setAlpha(alpha);
  lElbow.setAlpha(alpha);
  lWrist.setAlpha(alpha);
  lHand.setAlpha(alpha);
  
  bGrip.setAlpha(alpha);
  
  b90.setAlpha(alpha);
  b0.setAlpha(alpha);
  
  bHome.setAlpha(alpha);
  
  slider2dXY.setAlpha(alpha);
  slider2dXZ.setAlpha(alpha);
}

public void deactivateControls() {
  setControls(50);
  b90Send.setAlpha(50);
  b0Send.setAlpha(50);
  calibrationMode = false;
  sendingGcode = false;
}

public void activateControls() {
  setControls(255);
}

public void lockdown() {
  setControls(100);
}

public void lockup() {
  setControls(255);
}
  public void settings() {  size(1024, 720, JAVA2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "armInterfaceGUI" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
